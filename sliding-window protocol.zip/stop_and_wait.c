/* Um protocolo Stop_and_Wait SIMPLEX em canal livre de erros.
   Previne o TX de inundar o RX com frames mais r�pido que ele possa process�-los.
   O RX fornece feedback ao TX: frame de reconhecimento (ACK).
	 As camadas de rede do TX e do RX est�o sempre prontas.
   Canal de comunica��o � ideal: n�o estraga e nem perde pacotes txdos.
   Procedimento SENDER roda na camada de enlace da m�quina fonte (TX) e 
	 o procedimento RECEIVER roda na camada de enlace da m�quina destino (RX).
	 N�meros de sequ�ncia ou reconhecimentos n�o s�o usados.
	 TX transmite um frame e aguarda a confirma��o (reconhecimento) do RX.
	 �nico evento poss�vel � 'frame_arrival' (chegada de quadro sem erro).
	 
	 Fonte: Computer Networks, Andrew S. Tanembaum, 2014.
	 Adapta��o: Cl�udio A. Fleury, Ago/2019.
*/

/* Protocolo 2 (Stop_and_Wait) transmite dados numa �nica dire��o: TX para RX. 
   O canal de comunica��o � assumido como livre de erros, como no Protocolo 1.
	 O RX tem um buffer de capacidade finita e velocidade de processamento tbm finita.
	 O protocolo deve prevenir explicitamente o TX de inundar o RX com dados numa taxa
	 mais r�pida que o RX possa receber. */

typedef enum {frame_arrival} event_type;
#include "protocol.h"

void sender2(void) {
	frame s; 														/* buffer for an outbound frame */
	packet buffer; 											/* buffer for an outbound packet */
	event_type event; 									/* frame arrival is the only possibility */
	while (true) {
		from_network_layer(&buffer); 			/* go get something to send */
		s.info = buffer; 									/* copy it into s for transmission */
		to_physical_layer(&s); 						/* bye-bye little frame */
		wait_for_event(&event); 					/* wait for acknowledgemen */
	}
}

void receiver2(void) {
	frame r, s; 												/* buffers for frames */
	event_type event; 									/* frame arrival is the only possibility */
	while (true) {
		wait_for_event(&event); 					/* only possibility is frame arrival */
		from_physical_layer(&r); 					/* go get the inbound frame */
		to_network_layer(&r.info); 				/* pass the data to the network layer */
		to_physical_layer(&s); 						/* send a dummy frame to awaken sender */
	}
}
