/* Um protocolo SIMPLEX ut�pico: nada pode dar errado!
   As camadas de rede do TX e do RX est�o sempre prontas.
   Tempo de processamento � ignorado.
   Espa�o do buffer � "infinito".
   Canal de comunica��o � ideal: n�o estraga e nem perde pacotes txdos.
   Procedimento SENDER roda na camada de enlace da m�quina fonte (TX) e 
	 o procedimento RECEIVER roda na camada de enlace da m�quina destino (RX).
	 N�meros de sequ�ncia ou reconhecimentos n�o s�o usados.
	 �nico evento poss�vel � 'frame_arrival' (chegada de quadro sem erro).
	 
	 Fonte: Computer Networks, Andrew S. Tanembaum, 2014.
	 Adapta��o: Cl�udio A. Fleury, Ago/2019.
*/

/* Protocolo 1 (Utopia) transmite dados numa �nica dire��o: TX para RX. 
   O canal de comunica��o � assumido como livre de erros e o RX � capaz
	 de processar toda entrada de modo instant�neo. Consequentemente, o TX
	 simplesmente bombeia dados na linha t�o r�pido quanto ele pode... */
	 
typedef enum {frame_arrival} event_type;
#include "protocol.h"

void sender1(void) {
	frame s; 												/* buffer for an outbound frame */
	packet buffer; 									/* buffer for an outbound packet */
	while (true) {
		from_network_layer(&buffer); 	/* go get something to send */
		s.info = buffer; 							/* copy it into s for transmission */
		to_physical_layer(&s); 				/* send it on its way */
	} 
}

void receiver1(void) {
	frame r;
	event_type event; 							/* filled in by wait, but not used here */
	while (true) {
		wait_for_event(&event); 			/* only possibility is frame arrival */
		from_physical_layer(&r); 			/* go get the inbound frame */
		to_network_layer(&r.info); 		/* pass the data to the network layer */
	}
}

